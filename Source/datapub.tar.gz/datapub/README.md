## Datapub ##
###*A traffic Analyser* ###

Generation of charts on the basis of users visiting the different sites of the website (wordpress) and collection of stats. 

Note: This is a recent feature to be included in release 1.
