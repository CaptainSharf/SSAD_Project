articles = [{tags: ["b2b","b2g","blog","brand","channels","content","email","social"]},
{tags: ["analytics","b2b","brand","digitalmarketing","salesfunnel"]},
{tags: ["analytics","digitalmarketing"]},
{tags: ["salesfunnel","analytics","social"]},
{tags: ["analytics"]},
{tags: ["analytics","digitalmarketing"]}];

tagdata =[];
tagdata.push({
    externalTag: "digitalmarketing",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "digitalmarketing",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "digitalmarketing",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "digitalmarketing",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "digitalmarketing",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "digitalmarketing",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "digitalmarketing",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "digitalmarketing",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "digitalmarketing",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "digitalmarketing",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "digitalmarketing",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "digitalmarketing",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "digitalmarketing",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "digitalmarketing",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "digitalmarketing",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "digitalmarketing",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "digitalmarketing",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "digitalmarketing",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "social",
    internalTag: "content"
});
tagdata.push({
    externalTag: "social",
    internalTag: "content"
});
tagdata.push({
    externalTag: "social",
    internalTag: "content"
});
tagdata.push({
    externalTag: "social",
    internalTag: "content"
});
tagdata.push({
    externalTag: "social",
    internalTag: "content"
});
tagdata.push({
    externalTag: "social",
    internalTag: "content"
});
tagdata.push({
    externalTag: "social",
    internalTag: "content"
});
tagdata.push({
    externalTag: "social",
    internalTag: "content"
});
tagdata.push({
    externalTag: "social",
    internalTag: "content"
});
tagdata.push({
    externalTag: "social",
    internalTag: "content"
});
tagdata.push({
    externalTag: "social",
    internalTag: "content"
});
tagdata.push({
    externalTag: "social",
    internalTag: "content"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "salesfunnel"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "salesfunnel"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "salesfunnel"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "salesfunnel"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "salesfunnel"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "salesfunnel"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "salesfunnel"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "salesfunnel"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "salesfunnel"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "salesfunnel"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "salesfunnel"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "salesfunnel"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "salesfunnel"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "salesfunnel"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "salesfunnel"
});
tagdata.push({
    externalTag: "social",
    internalTag: "email"
});
tagdata.push({
    externalTag: "social",
    internalTag: "email"
});
tagdata.push({
    externalTag: "social",
    internalTag: "email"
});
tagdata.push({
    externalTag: "social",
    internalTag: "email"
});
tagdata.push({
    externalTag: "social",
    internalTag: "email"
});
tagdata.push({
    externalTag: "social",
    internalTag: "email"
});
tagdata.push({
    externalTag: "social",
    internalTag: "email"
});
tagdata.push({
    externalTag: "social",
    internalTag: "email"
});
tagdata.push({
    externalTag: "social",
    internalTag: "email"
});
tagdata.push({
    externalTag: "social",
    internalTag: "email"
});
tagdata.push({
    externalTag: "social",
    internalTag: "email"
});
tagdata.push({
    externalTag: "social",
    internalTag: "email"
});
tagdata.push({
    externalTag: "social",
    internalTag: "email"
});
tagdata.push({
    externalTag: "social",
    internalTag: "email"
});
tagdata.push({
    externalTag: "social",
    internalTag: "email"
});
tagdata.push({
    externalTag: "social",
    internalTag: "email"
});
tagdata.push({
    externalTag: "social",
    internalTag: "email"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "analytics",
    internalTag: "digitalmarketing"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
tagdata.push({
    externalTag: "b2b",
    internalTag: "brand"
});
